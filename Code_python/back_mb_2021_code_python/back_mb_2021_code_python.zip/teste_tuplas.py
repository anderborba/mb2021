## Importa as bibliotecas iniciais a serem utilizadas
import numpy as np
import scipy.io as sio
from skimage import exposure
import matplotlib as mpl
import matplotlib.pyplot as plt
import pywt
#from mpl_toolkits.mplot3d import Axes3D
#import matplotlib.pyplot as plt
#from matplotlib import cm
#from matplotlib.ticker import LinearLocator, FormatStrFormatter
#import numpy as np
import math
#import os
#from scipy.optimize import minimize
from scipy.optimize import dual_annealing

coef = pywt.dwt2(E[ :, :, canal], 'db2')
